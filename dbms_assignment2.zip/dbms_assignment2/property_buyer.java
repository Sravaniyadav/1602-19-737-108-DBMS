package dbms_assignment2;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import com.sun.jdi.connect.spi.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class property_buyer {

	private JFrame frame;
	private JTextField textname;
	private JTextField txtmailid;
	private JTable table;
	
	private JTextField txtid;
     
	

	
     public static void main(String[] args) {
    	 property_buyer sh=new property_buyer();
     }

	

	/**
	 * Create the application.
	 */
	public property_buyer() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}

	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	private JTable table_1;
	private JTextField textmobile;
	private JTextField textaddress;
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sravani","vasavi");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1120, 618);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("property_buyer");
		lblNewLabel.setBounds(355, 10, 358, 43);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(80, 64, 478, 327);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("BUYER_NAME");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 10, 202, 49);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("BUYER_MAIL ID");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(10, 97, 184, 26);
		panel.add(lblNewLabel_3);
		
		textname = new JTextField();
		textname.setBounds(239, 23, 147, 31);
		panel.add(textname);
		textname.setColumns(10);
		
		txtmailid = new JTextField();
		txtmailid.setBounds(239, 99, 147, 31);
		panel.add(txtmailid);
		txtmailid.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("BUYER_MOBILENO");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2_1.setBounds(10, 158, 202, 49);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("BUYER_ADDRESS");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2_2.setBounds(10, 226, 202, 49);
		panel.add(lblNewLabel_2_2);
		
		textmobile = new JTextField();
		textmobile.setBounds(239, 170, 147, 26);
		panel.add(textmobile);
		textmobile.setColumns(10);
		
		textaddress = new JTextField();
		textaddress.setBounds(239, 233, 151, 31);
		panel.add(textaddress);
		textaddress.setColumns(10);
		
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					int id;
					String name,mailid,mobile,address;
					id=	Integer.parseInt(txtid.getText());
					name=textname.getText();
				   mailid=txtmailid.getText();
				   mobile=textmobile.getText();
				   address=textaddress.getText();
				   
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into property_buyer values (?,?,?,?,?)");
		            	        pstmt.setInt(1, id);
		            	       pstmt.setString(2,name);
		            	        pstmt.setString(3,mailid);
		            	        pstmt.setString(4, mobile);
		            	        pstmt.setString(5,address);
		            	        int i=pstmt.executeUpdate();  
					   
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(81, 417, 175, 54);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("CLEAR");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtid.setText("");
				textname.setText("");
			    txtmailid.setText("");
			   textmobile.setText("");
			   textaddress.setText("");
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(355, 417, 175, 54);
		frame.getContentPane().add(btnExit);
		
		table = new JTable();
		table.setBounds(714, 327, 1, 1);
		frame.getContentPane().add(table);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(70, 507, 330, 53);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel id = new JLabel("buyer_id");
		id.setFont(new Font("Tahoma", Font.BOLD, 20));
		id.setBounds(10, 11, 144, 26);
		panel_1.add(id);
		
		txtid = new JTextField();
		txtid.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String ID;
					ID=txtid.getText();
					
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from property_buyer where buyer_id=(?)");
	            	 pstmt1.setString(1, ID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	// txtid.setText(rs.getString(1));
	            	 textname.setText(rs.getString(2));
	            	 txtmailid.setText(rs.getString(3));
	            	 textmobile.setText(rs.getString(4));
	            	 textaddress.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		txtid.setColumns(10);
		txtid.setBounds(126, 13, 147, 31);
		panel_1.add(txtid);
		
		JButton btnNewButton_1 = new JButton("UPDATE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1) {
					int id;
					String name,mailid,mobile,address;
					id=	Integer.parseInt(txtid.getText());
					name=textname.getText();
				   mailid=txtmailid.getText();
				   mobile=textmobile.getText();
				   address=textaddress.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  property_buyer set BUYER_NAME=(?),BUYER_MAILID=(?),BUYER_MBLNO=(?),BUYER_ADRS=(?) where BUYER_ID=(?)");
	            	 pstmt.setInt(5, id);
          	       pstmt.setString(1,name);
          	        pstmt.setString(2,mailid);
          	        pstmt.setString(3, mobile);
          	        pstmt.setString(4,address);
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.setBounds(616, 83, 175, 57);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("DELETE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_2) {
					String ID;
					ID=txtid.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from property_buyer where BUYER_ID=(?)");
		            	        pstmt.setString(1, ID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(628, 198, 163, 54);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("view");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_3) {
					viewproperty_buyer vs=new viewproperty_buyer();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 21));
		btnNewButton_3.setBounds(638, 319, 153, 57);
		frame.getContentPane().add(btnNewButton_3);

	}
}
