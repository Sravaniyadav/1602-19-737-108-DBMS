package dbms_assignment2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import com.sun.jdi.connect.spi.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class Agent {

	private JFrame frame;
	private JTextField txtagent_name;
	private JTextField txtagent_mailid;
	private JTextField txtagent_mblno;
	private JTextField txtagent_adrs;
	private JTextField txtowner_id;
	private JTextField buyer_id;
	private JTextField txtagent_id;

	/**
	 * Launch the application.
	 */
	public class agent {

		private JFrame frame;
		private JTextField txtagent_name;
		private JTextField txtagent_mailid;
		private JTable table;
		
		private JTextField txtagent_id;
	     
		

		
	     public static void main(String[] args) {
	    	 agent sh=new agent();
	     }

		

		/**
		 * Create the application.
		 */
		public agent() {
			initialize();
			this.frame.setVisible(true);
			Connect();
		}

		java.sql.Connection con;
		Statement stmt;
		ResultSet rs;
		private JTable table_1;
		private JTextField txtagent_mblno;
		private JTextField txtagent_adrs;
	           
	 
		 public void Connect()
		    {
			 try 
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} 
				catch (Exception e) 
				{
					System.err.println("Unable to find and load driver");
					System.exit(1);
				}
			 try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sravani","vasavi");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Agent window = new Agent();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public void Agent() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 841, 586);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Agent");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(322, 27, 114, 31);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "registration", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(88, 93, 302, 260);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("agent_name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(27, 35, 112, 25);
		panel.add(lblNewLabel_1);
		
		txtagent_name = new JTextField();
		txtagent_name.setBounds(145, 42, 130, 18);
		panel.add(txtagent_name);
		txtagent_name.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("agent_mailid");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_1.setBounds(27, 75, 112, 25);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("agent_mblno");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_2.setBounds(27, 111, 112, 25);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("agent_adrs");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_3.setBounds(27, 147, 112, 25);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("owner_id");
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_4.setBounds(27, 183, 112, 25);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("buyer_id");
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1_5.setBounds(27, 219, 112, 25);
		panel.add(lblNewLabel_1_5);
		
		txtagent_mailid = new JTextField();
		txtagent_mailid.setColumns(10);
		txtagent_mailid.setBounds(145, 82, 130, 18);
		panel.add(txtagent_mailid);
		
		txtagent_mblno = new JTextField();
		txtagent_mblno.setColumns(10);
		txtagent_mblno.setBounds(145, 111, 130, 18);
		panel.add(txtagent_mblno);
		
		txtagent_adrs = new JTextField();
		txtagent_adrs.setColumns(10);
		txtagent_adrs.setBounds(145, 147, 130, 18);
		panel.add(txtagent_adrs);
		
		txtowner_id = new JTextField();
		txtowner_id.setColumns(10);
		txtowner_id.setBounds(145, 187, 130, 18);
		panel.add(txtowner_id);
		
		buyer_id = new JTextField();
		buyer_id.setColumns(10);
		buyer_id.setBounds(145, 224, 130, 18);
		panel.add(buyer_id);
		
		JButton btnNewButton = new JButton("add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int agent_id,buyer_id,owner_id,agent_mblno;
				String agent_name,agent_mailid,agent_adrs;
				agent_id=Integer.parseInt(txtagent_id.getText());
                 owner_id=Integer.parseInt(txtowner_id.getText());
                  buyer_id=Integer.parseInt(buyer_id.getText());
                 agent_mblno=Integer.parseInt(txtagent_mblno.getText());
				agent_name=txtagent_name.getText();
			        agent_mailid=txtagent_mailid.getText();
			 
			        agent_adrs=txtagent_adrs.getText();
			   
				
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("insert into agent values (?,?,?,?,?,?,?)");
	            	        pstmt.setInt(1, agent_id);
	            	       pstmt.setString(2,agent_name);
	            	        pstmt.setString(3,agent_mailid);
	            	        pstmt.setInt(4,agent_mblno);
	            	        pstmt.setString(5,agent_adrs);
                                      pstmt.setInt(6,owner_id);
                                      pstmt.setInt(7,buyer_id);
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
			}
		});
		btnNewButton.setBounds(88, 384, 89, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnClear = new JButton("clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtagent_id.setText("");
				txtagent_name.setText("");
			    txtagent_mailid.setText("");
			   txtagent_mblno.setText("");
			   txtagent_adrs.setText("");
               txtowner_id.setText("");
               buyer_id.setText("");
			}
		});
		btnClear.setBounds(301, 384, 89, 38);
		frame.getContentPane().add(btnClear);
		
		JButton btnUpdate = new JButton("update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnUpdate) {
					int agent_id,owner_id,buyer_id,agent_mblno;
					String agent_name,agent_mailid,agent_adrs;
					agent_id=Integer.parseInt(txtagent_id.getText());
                    buyer_id=Integer.parseInt(buyer_id.getText());
                    owner_id=Integer.parseInt(txtowner_id.getText());
					agent_name=txtagent_name.getText();
				        agent_mailid=txtagent_mailid.getText();
				  
				        agent_adrs=txtagent_adrs.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  agent set AGENT_NAME=(?),AGENT_MAILID=(?),AGENT_MBLNO=(?),AGENT_ADRS=(?),OWNER_ID=(?),BUYER_ID=(?) where AGENT_ID=(?)");
	            	 pstmt.setInt(5, agent_id);
          	        pstmt.setString(1,agent_name);
          	        pstmt.setString(2,agent_mailid);
          	        pstmt.setInt(3,agent_mblno);
          	        pstmt.setString(4,agent_adrs);
                        pstmt.setInt(6,owner_id);
                        pstmt.setInt(7,buyer_id);
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		
		
		});
		btnUpdate.setBounds(576, 99, 89, 38);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnDelete) {
					String AGENT_ID;
					AGENT_ID=txtagent_id.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from agent where AGENT_ID=(?)");
		            	        pstmt.setString(1, AGENT_ID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnDelete.setBounds(576, 184, 89, 38);
		frame.getContentPane().add(btnDelete);
		
		JButton btnView = new JButton("view");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnView) {
					viewagent vs=new viewagent();
				}
			}
		});
		btnView.setBounds(576, 271, 89, 38);
		frame.getContentPane().add(btnView);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(81, 475, 339, 61);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("agent_id");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(30, 17, 110, 30);
		panel_1.add(lblNewLabel_2);
		
		txtagent_id= new JTextField();
		txtagent_id.setColumns(10);
		txtagent_id.setBounds(185, 25, 130, 18);
		panel_1.add(txtagent_id);
	}
	}

