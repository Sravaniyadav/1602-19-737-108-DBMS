package dbms_assignment2;



import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;

import javax.swing.border.TitledBorder;


import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class property_details {

	private JFrame frame;
	private JTextField txtproperty_lctn;
	private JTextField txt_tval;
	private JTable table;
	
	private JTextField txtid;
     
	

	
     public static void main(String[] args) {
    	 
    	 property_details sh=new property_details();
     }

	

	/**
	 * Create the application.
	 */
	public property_details() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}

	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	
	private JTextField txt_property_status;
	private JTextField txt_owner_id;
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sravani","vasavi");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1120, 618);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("property_details");
		lblNewLabel.setBounds(355, 10, 358, 43);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(80, 64, 478, 327);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("PROPERTY_LCTN");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 10, 202, 49);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("TVAL");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(10, 97, 184, 26);
		panel.add(lblNewLabel_3);
		
		txtproperty_lctn = new JTextField();
		txtproperty_lctn.setBounds(239, 23, 147, 31);
		panel.add(txtproperty_lctn);
		txtproperty_lctn.setColumns(10);
		
		txt_tval = new JTextField();
		txt_tval.setBounds(239, 99, 147, 31);
		panel.add(txt_tval);
		txt_tval.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("PROPERTY_STATUS");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2_1.setBounds(10, 158, 202, 49);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("OWNER_ID");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2_2.setBounds(10, 226, 202, 49);
		panel.add(lblNewLabel_2_2);
		
		txt_property_status = new JTextField();
		txt_property_status.setBounds(239, 170, 147, 26);
		panel.add(txt_property_status);
		txt_property_status.setColumns(10);
		
		txt_owner_id = new JTextField();
		txt_owner_id.setBounds(239, 233, 151, 31);
		panel.add(txt_owner_id);
		txt_owner_id.setColumns(10);
		
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					int id,owner_id,tval;
					String property_lctn,property_status;
					id=Integer.parseInt(txtid.getText());
                    tval=Integer.parseInt(txt_tval.getText());
                    owner_id=Integer.parseInt(txt_owner_id.getText());
	                property_lctn=txtproperty_lctn.getText();
				       
				        property_status=txt_property_status.getText();
				
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into property_details values (?,?,?,?,?)");
		            	        pstmt.setInt(1, id);;
		            	       
		            	        pstmt.setString(2,property_lctn);
		            	        pstmt.setInt(3,tval);
		            	        pstmt.setString(4,property_status);
		            	        pstmt.setInt(5,owner_id);
		            	        int i=pstmt.executeUpdate();  
					   
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(81, 417, 175, 54);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("CLEAR");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtid.setText("");
				txtproperty_lctn.setText("");
			    txt_tval.setText("");
			   txt_property_status.setText("");
			   txt_owner_id.setText("");
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(355, 417, 175, 54);
		frame.getContentPane().add(btnExit);
		
		table = new JTable();
		table.setBounds(714, 327, 1, 1);
		frame.getContentPane().add(table);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(70, 507, 330, 53);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel id = new JLabel("id");
		id.setFont(new Font("Tahoma", Font.BOLD, 20));
		id.setBounds(10, 11, 144, 26);
		panel_1.add(id);
		
		txtid = new JTextField();
		txtid.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String ID;
					ID=txtid.getText();
					
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from property_details where id=(?)");
	            	 pstmt1.setString(1, ID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	// txtid.setText(rs.getString(1));
	            	 txtproperty_lctn.setText(rs.getString(2));
	            	 txt_tval.setText(rs.getString(3));
	            	 txt_property_status.setText(rs.getString(4));
	            	 txt_owner_id.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		txtid.setColumns(10);
		txtid.setBounds(126, 13, 147, 31);
		panel_1.add(txtid);
		
		JButton btnNewButton_1 = new JButton("UPDATE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1) {
					int id,owner_id,tval;
					String property_lctn,property_status;
					id=Integer.parseInt(txtid.getText());
                                        owner_id=Integer.parseInt(txt_owner_id.getText());
                                        tval=Integer.parseInt(txt_tval.getText());
					property_lctn=txtproperty_lctn.getText();
				   
				        property_status=txt_property_status.getText();
				  
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  property_details set PROPERTY_LCTN=(?),TVAL=(?),PROPERTY_STATUS=(?),OWNER_ID=(?) where ID=(?)");
	            	 pstmt.setInt(5, id);
          	       pstmt.setString(1,property_lctn);
          	        pstmt.setInt(2,tval);
          	        pstmt.setString(3,property_status);
          	        pstmt.setInt(4,owner_id);
	            	        int i=pstmt.executeUpdate();  
				   
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.setBounds(616, 83, 175, 57);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("DELETE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_2) {
					String ID;
					ID=txtid.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from property_details where ID=(?)");
		            	        pstmt.setString(1, ID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(628, 198, 163, 54);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("view");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_3) {
					viewproperty_details vs=new viewproperty_details();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 21));
		btnNewButton_3.setBounds(638, 319, 153, 57);
		frame.getContentPane().add(btnNewButton_3);

	}
}
