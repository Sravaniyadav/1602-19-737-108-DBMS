package dbms_assignment2;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

class viewproperty_details {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_2;
		private JLabel lblNewLabel_3;
		private JLabel lblNewLabel_4;
		/**
		 * Create the application.
		 */
		viewproperty_details() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","sravani","vasavi");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("property details");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from property_details");
				
				int i=0;
				while(rs.next()) {
					
					
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					tbl[i][2]=rs.getString(3);
					tbl[i][3]=rs.getString(4);
					tbl[i][4]=rs.getString(5);
				
					i=i+1;
					
				}
				
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"ID", "PROPERTY_LCTN", "TVAL", "PROPERTY_STATUS", "OWNER_ID"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel(" ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(48, 95, 50, 32);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("PROPERTY_STATUS");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_1.setBounds(602, 89, 104, 39);
			frame.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_2 = new JLabel("PROPERTY_LCTN");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_2.setBounds(130, 89, 199, 45);
			frame.getContentPane().add(lblNewLabel_2);
			
			lblNewLabel_3 = new JLabel("TVAL");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_3.setBounds(256, 89, 199, 45);
			frame.getContentPane().add(lblNewLabel_3);
			
			lblNewLabel_4 = new JLabel("OWNER_ID");
			lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_4.setBounds(418, 89, 199, 45);
			frame.getContentPane().add(lblNewLabel_4);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}

 